package com.nouradine.agriculture;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout content;
    private EditText search;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(0xFF183B2B);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(12, 12, 12, 12);
        return t;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void base(String title) {
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(20, 18, 20, 24);
        content.setBackgroundColor(0xFFF4F7F1);
        scroll.addView(content);
        setContentView(scroll);
        content.addView(text(title, 25, true));
    }

    private void showHome() {
        base("كتاب الزراعة\nنورالدين ميدني");
        content.addView(text("تعلّم، فكّر، واقرأ", 17, false));
        content.addView(text("موسوعة زراعية عربية وعالمية", 16, true));
        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("ابحث عن محصول أو مرض أو طريقة ري...");
        content.addView(search);
        content.addView(button("بحث في الدروس التجريبية", () -> searchLessons(search.getText().toString())));
        content.addView(button("الموسوعة الزراعية", () -> showSection("الموسوعة الزراعية",
                "دليل المحاصيل\nالتربة وتحليلها\nالري وشبكات التنقيط\nالأسمدة والعناصر الغذائية\nالآفات والأمراض\nالبيوت المحمية\nالزراعة في المناخات المختلفة")));
        content.addView(button("الري وشبكات المياه", () -> showSection("الري وشبكات المياه",
                "الري بالتنقيط: يوصل الماء ببطء إلى منطقة الجذور.\n\nقبل اختيار نظام الري، افحص مصدر المياه والتربة واحتياجات المحصول.\n\nيجب ضبط الضغط والمرشحات والنقاطات حسب مواصفات النظام.")));
        content.addView(button("الأمراض والآفات", () -> showSection("الأمراض والآفات",
                "افحص النبات وحدد الأعراض أولاً: لون الأوراق، شكل البقع، وجود حشرات، وانتشار الإصابة.\n\nلا تستخدم مبيداً أو جرعة قبل تحديد الآفة والمحصول وقراءة ملصق المنتج المحلي.")));
        content.addView(button("مساعد نورالدين الزراعي الذكي", () -> showSection("المساعد الزراعي",
                "هذه واجهة أولية للمساعد. في المرحلة التالية نربطها بخدمة ذكاء اصطناعي لتحليل الأسئلة والصور.\n\nتنبيه: هذه النسخة لا تشخّص الأمراض ولا تعطي جرعات مبيدات.")));
        content.addView(button("English", () -> showSection("Agriculture Book",
                "Learn, Think & Read\nCrop guides\nSoil and water\nIrrigation systems\nFertilizers\nPests and diseases\nGreenhouse farming")));
        content.addView(text("الإصدار الأولي 1.0.0 — قيد التطوير", 13, false));
    }

    private void searchLessons(String q) {
        String query = q.trim().toLowerCase();
        if (query.isEmpty()) { showSection("نتائج البحث", "اكتب كلمة للبحث."); return; }
        String result = "لم نعثر على درس مطابق في العينة الحالية.\n\nسيتم توسيع قاعدة المعرفة وإضافة البحث عبر الإنترنت في مرحلة لاحقة.";
        if (query.contains("ري") || query.contains("ماء")) result = "الري: اختر طريقة الري حسب المحصول والتربة ومصدر المياه. افحص الضغط والمرشحات بانتظام.";
        else if (query.contains("طماطم")) result = "الطماطم: تحتاج إلى شمس كافية وتربة جيدة الصرف وري منتظم دون إغراق.";
        else if (query.contains("تربة")) result = "التربة: افحص القوام والملوحة ودرجة الحموضة والمادة العضوية قبل وضع برنامج التسميد.";
        showSection("نتائج البحث", result);
    }

    private void showSection(String title, String body) {
        base(title);
        TextView details = text(body, 17, false);
        details.setGravity(Gravity.RIGHT);
        content.addView(details);
        content.addView(button("العودة إلى الرئيسية", this::showHome));
    }
}

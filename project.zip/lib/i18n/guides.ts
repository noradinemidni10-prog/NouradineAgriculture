import type { Locale } from './dictionaries'

export type CropId = 'tomato' | 'pepper' | 'trees'
export type SectionId = 'planting' | 'irrigation' | 'fertilization' | 'problems' | 'harvest'

export interface CropGuide {
  id: CropId
  name: string
  summary: string
  image: string
  sections: Record<SectionId, string[]>
}

export interface CareTopic {
  id: 'irrigation' | 'fertilization' | 'treatments'
  title: string
  intro: string
  points: string[]
}

const images: Record<CropId, string> = {
  tomato: '/images/tomato.jpg',
  pepper: '/images/pepper.jpg',
  trees: '/images/trees.jpg',
}

const crops: Record<Locale, CropGuide[]> = {
  ar: [
    {
      id: 'tomato',
      name: 'الطماطم',
      summary: 'محصول صيفي يحتاج شمساً كاملة وتربة جيدة الصرف وحرارة بين 20 و30 درجة.',
      image: images.tomato,
      sections: {
        planting: [
          'ازرع البذور في المشتل قبل 6–8 أسابيع من الشتل، وانقل الشتلات عند ظهور 4–6 أوراق حقيقية.',
          'تربة طميية خفيفة غنية بالمادة العضوية، ودرجة حموضة بين 6.0 و6.8.',
          'المسافة 40–50 سم بين النباتات و1–1.2 م بين الخطوط، مع تركيب دعامات أو خيوط تربية.',
        ],
        irrigation: [
          'الري بالتنقيط هو الأفضل؛ حافظ على رطوبة منتظمة دون غمر.',
          'في الصيف: 2–4 لترات لكل نبتة يومياً حسب الحرارة ونوع التربة.',
          'تذبذب الري يسبب تشقق الثمار وتعفن الطرف الزهري.',
        ],
        fertilization: [
          'قبل الزراعة: 3–4 كغ سماد عضوي متحلل لكل متر مربع.',
          'بعد الشتل: سماد غني بالفوسفور لتقوية الجذور (مثل 10-52-10).',
          'عند الإزهار والعقد: زد البوتاسيوم والكالسيوم (مثل 12-12-36 + نترات الكالسيوم).',
        ],
        problems: [
          'اللفحة المتأخرة: بقع بنية مائية — أزل الأوراق المصابة ورش مبيداً نحاسياً أو مانكوزيب.',
          'الذبابة البيضاء والتوتا أبسولوتا: مصائد صفراء وفرمونية، زيت النيم، وعند الإصابة الشديدة مبيد متخصص.',
          'تعفن الطرف الزهري: نقص كالسيوم وري غير منتظم — انتظم في الري ورش الكالسيوم.',
        ],
        harvest: [
          'يبدأ الحصاد بعد 60–90 يوماً من الشتل حسب الصنف.',
          'اقطف الثمار عند بداية التلوّن للنقل البعيد، وكاملة الاحمرار للاستهلاك المحلي.',
        ],
      },
    },
    {
      id: 'pepper',
      name: 'الفلفل',
      summary: 'يحب الدفء ويتأثر بالبرد، ويحتاج تربة خصبة وري منتظم.',
      image: images.pepper,
      sections: {
        planting: [
          'ابدأ في المشتل قبل 8–10 أسابيع؛ الإنبات الأفضل بين 25 و30 درجة.',
          'اشتل عندما تتجاوز حرارة الليل 15 درجة.',
          'المسافة 35–45 سم بين النباتات و70–90 سم بين الخطوط.',
        ],
        irrigation: [
          'رطوبة متوسطة ومنتظمة؛ الجفاف وقت الإزهار يسبب تساقط الأزهار.',
          'استخدم التغطية (الملش) لتقليل التبخر وتثبيت حرارة التربة.',
        ],
        fertilization: [
          'سماد عضوي قبل الزراعة، ثم نيتروجين معتدل في مرحلة النمو الخضري.',
          'عند الإزهار والإثمار: بوتاسيوم أعلى مع مغنيسيوم وعناصر صغرى.',
          'زيادة النيتروجين تعطي أوراقاً كثيرة وثماراً قليلة.',
        ],
        problems: [
          'المن والتربس: رش صابون بوتاسي أو زيت النيم وراقب الأعداء الطبيعيين.',
          'ذبول الفيوزاريوم: دورة زراعية وتعقيم التربة واستخدام أصناف مقاومة.',
          'لسعة الشمس على الثمار: حافظ على كثافة أوراق جيدة أو استخدم شباك تظليل.',
        ],
        harvest: [
          'يمكن قطف الفلفل أخضر بعد اكتمال حجمه، أو تركه حتى يتلوّن لطعم أحلى.',
          'اقطع الثمار بمقص لتجنب كسر الأغصان.',
        ],
      },
    },
    {
      id: 'trees',
      name: 'الأشجار المثمرة',
      summary: 'الزيتون والحمضيات واللوزيات: استثمار طويل يحتاج تخطيطاً جيداً للري والتقليم.',
      image: images.trees,
      sections: {
        planting: [
          'ازرع في الخريف أو أواخر الشتاء في حفرة 60×60×60 سم مع سماد عضوي متحلل.',
          'اختر أصنافاً تناسب مناخك وتربتك، وتجنب الأراضي التي يتجمع فيها الماء.',
          'المسافات: زيتون 6–8 م، حمضيات 5–6 م، لوزيات 5–6 م.',
        ],
        irrigation: [
          'الشجرة الصغيرة: ري أسبوعي عميق في الصيف.',
          'الشجرة المثمرة: الحاجة الأكبر وقت الإزهار وعقد الثمار وتضخمها.',
          'الري بالتنقيط حول محيط التاج، وليس ملاصقاً للجذع.',
        ],
        fertilization: [
          'نهاية الشتاء: سماد عضوي + نيتروجين لبداية النمو.',
          'الربيع والصيف: NPK متوازن ثم بوتاسيوم عند تضخم الثمار.',
          'اصفرار الأوراق مع بقاء العروق خضراء في الحمضيات يدل غالباً على نقص الحديد.',
        ],
        problems: [
          'المن والحشرات القشرية: زيت معدني صيفي أو زيت النيم.',
          'عين الطاووس في الزيتون: رش النحاس في الخريف وبعد الأمطار.',
          'ذبابة الفاكهة: مصائد غذائية وجمع الثمار المتساقطة.',
        ],
        harvest: [
          'التقليم الشتوي يحسّن التهوية والإنتاج؛ أزل الأفرع الميتة والمتشابكة.',
          'اقطف حسب نضج الصنف، وتجنب ضرب الأغصان في الزيتون.',
        ],
      },
    },
  ],
  fr: [
    {
      id: 'tomato',
      name: 'Tomate',
      summary: 'Culture d’été exigeant plein soleil, sol bien drainé et 20 à 30 °C.',
      image: images.tomato,
      sections: {
        planting: [
          'Semez en pépinière 6 à 8 semaines avant la plantation ; repiquez à 4–6 vraies feuilles.',
          'Sol limoneux léger riche en matière organique, pH entre 6,0 et 6,8.',
          '40–50 cm entre plants et 1–1,2 m entre rangs, avec tuteurs ou ficelles.',
        ],
        irrigation: [
          'Le goutte-à-goutte est idéal ; gardez une humidité régulière sans excès.',
          'En été : 2 à 4 litres par plant et par jour selon la chaleur et le sol.',
          'Un arrosage irrégulier provoque l’éclatement des fruits et la nécrose apicale.',
        ],
        fertilization: [
          'Avant plantation : 3 à 4 kg de fumier décomposé par m².',
          'Après repiquage : engrais riche en phosphore pour l’enracinement (ex. 10-52-10).',
          'Floraison et nouaison : plus de potassium et de calcium (ex. 12-12-36 + nitrate de calcium).',
        ],
        problems: [
          'Mildiou : taches brunes huileuses — retirez les feuilles atteintes, traitez au cuivre ou au mancozèbe.',
          'Aleurodes et Tuta absoluta : pièges jaunes et à phéromones, huile de neem, insecticide spécifique si nécessaire.',
          'Nécrose apicale : manque de calcium et arrosage irrégulier — régularisez et pulvérisez du calcium.',
        ],
        harvest: [
          'Récolte 60 à 90 jours après plantation selon la variété.',
          'Cueillez au tournant pour le transport, bien rouges pour la vente locale.',
        ],
      },
    },
    {
      id: 'pepper',
      name: 'Poivron',
      summary: 'Aime la chaleur, craint le froid, demande un sol fertile et un arrosage régulier.',
      image: images.pepper,
      sections: {
        planting: [
          'Semez en pépinière 8 à 10 semaines avant ; germination optimale entre 25 et 30 °C.',
          'Plantez quand les nuits dépassent 15 °C.',
          '35–45 cm entre plants et 70–90 cm entre rangs.',
        ],
        irrigation: [
          'Humidité modérée et régulière ; la sécheresse en floraison fait chuter les fleurs.',
          'Paillez pour limiter l’évaporation et stabiliser la température du sol.',
        ],
        fertilization: [
          'Fumure organique avant plantation, puis azote modéré en croissance.',
          'Floraison et fructification : plus de potassium avec magnésium et oligo-éléments.',
          'Trop d’azote donne beaucoup de feuilles et peu de fruits.',
        ],
        problems: [
          'Pucerons et thrips : savon noir ou huile de neem, favorisez les auxiliaires.',
          'Fusariose : rotation, désinfection du sol et variétés résistantes.',
          'Coup de soleil sur fruits : gardez un bon feuillage ou utilisez un filet d’ombrage.',
        ],
        harvest: [
          'Récoltez vert à taille finale, ou attendez la coloration pour plus de douceur.',
          'Coupez au sécateur pour ne pas casser les branches.',
        ],
      },
    },
    {
      id: 'trees',
      name: 'Arbres fruitiers',
      summary: 'Olivier, agrumes et fruits à noyau : un investissement durable qui demande irrigation et taille bien planifiées.',
      image: images.trees,
      sections: {
        planting: [
          'Plantez en automne ou fin d’hiver dans un trou de 60×60×60 cm avec du fumier décomposé.',
          'Choisissez des variétés adaptées au climat et évitez les sols où l’eau stagne.',
          'Espacements : olivier 6–8 m, agrumes 5–6 m, fruits à noyau 5–6 m.',
        ],
        irrigation: [
          'Jeune arbre : arrosage profond hebdomadaire en été.',
          'Arbre en production : besoins maximaux à la floraison, à la nouaison et au grossissement.',
          'Goutte-à-goutte sous la périphérie de la frondaison, pas contre le tronc.',
        ],
        fertilization: [
          'Fin d’hiver : fumure organique + azote pour le départ de végétation.',
          'Printemps–été : NPK équilibré puis potassium au grossissement des fruits.',
          'Chlorose avec nervures vertes chez les agrumes : souvent une carence en fer.',
        ],
        problems: [
          'Pucerons et cochenilles : huile minérale d’été ou huile de neem.',
          'Œil de paon de l’olivier : cuivre en automne et après les pluies.',
          'Mouche des fruits : pièges alimentaires et ramassage des fruits tombés.',
        ],
        harvest: [
          'La taille d’hiver améliore l’aération et la production ; retirez le bois mort.',
          'Récoltez selon la maturité de la variété, sans gauler brutalement les oliviers.',
        ],
      },
    },
  ],
  en: [
    {
      id: 'tomato',
      name: 'Tomato',
      summary: 'A summer crop that needs full sun, well-drained soil and 20–30 °C.',
      image: images.tomato,
      sections: {
        planting: [
          'Sow in a nursery 6–8 weeks before transplanting; move seedlings at 4–6 true leaves.',
          'Light loamy soil rich in organic matter, pH 6.0–6.8.',
          '40–50 cm between plants and 1–1.2 m between rows, with stakes or trellis strings.',
        ],
        irrigation: [
          'Drip irrigation is best; keep moisture steady without flooding.',
          'In summer: 2–4 liters per plant per day depending on heat and soil.',
          'Irregular watering causes fruit cracking and blossom-end rot.',
        ],
        fertilization: [
          'Before planting: 3–4 kg of well-rotted manure per m².',
          'After transplanting: phosphorus-rich fertilizer for roots (e.g. 10-52-10).',
          'At flowering and fruit set: more potassium and calcium (e.g. 12-12-36 + calcium nitrate).',
        ],
        problems: [
          'Late blight: brown water-soaked spots — remove infected leaves, spray copper or mancozeb.',
          'Whitefly and Tuta absoluta: yellow and pheromone traps, neem oil, a targeted insecticide if severe.',
          'Blossom-end rot: calcium shortage and uneven watering — water regularly and spray calcium.',
        ],
        harvest: [
          'Harvest begins 60–90 days after transplanting depending on the variety.',
          'Pick at first color for long transport, fully red for local sale.',
        ],
      },
    },
    {
      id: 'pepper',
      name: 'Pepper',
      summary: 'Loves warmth, dislikes cold, and needs fertile soil with steady watering.',
      image: images.pepper,
      sections: {
        planting: [
          'Start in a nursery 8–10 weeks ahead; best germination at 25–30 °C.',
          'Transplant once night temperatures stay above 15 °C.',
          '35–45 cm between plants and 70–90 cm between rows.',
        ],
        irrigation: [
          'Moderate, consistent moisture; drought at flowering causes flower drop.',
          'Use mulch to reduce evaporation and stabilize soil temperature.',
        ],
        fertilization: [
          'Organic matter before planting, then moderate nitrogen during vegetative growth.',
          'At flowering and fruiting: more potassium with magnesium and micronutrients.',
          'Too much nitrogen gives lots of leaves and few fruits.',
        ],
        problems: [
          'Aphids and thrips: potassium soap or neem oil, and encourage beneficial insects.',
          'Fusarium wilt: crop rotation, soil sanitation and resistant varieties.',
          'Sunscald on fruit: keep good leaf cover or use shade netting.',
        ],
        harvest: [
          'Pick green at full size, or wait for color for a sweeter taste.',
          'Cut fruit with shears to avoid breaking branches.',
        ],
      },
    },
    {
      id: 'trees',
      name: 'Fruit trees',
      summary: 'Olive, citrus and stone fruits: a long-term investment that needs planned irrigation and pruning.',
      image: images.trees,
      sections: {
        planting: [
          'Plant in autumn or late winter in a 60×60×60 cm hole with rotted manure.',
          'Choose varieties suited to your climate and avoid waterlogged ground.',
          'Spacing: olive 6–8 m, citrus 5–6 m, stone fruits 5–6 m.',
        ],
        irrigation: [
          'Young trees: deep weekly watering in summer.',
          'Bearing trees: highest needs at flowering, fruit set and fruit sizing.',
          'Place drippers around the canopy edge, not against the trunk.',
        ],
        fertilization: [
          'Late winter: organic matter + nitrogen for spring growth.',
          'Spring–summer: balanced NPK, then potassium as fruit sizes up.',
          'Yellow leaves with green veins on citrus usually mean iron deficiency.',
        ],
        problems: [
          'Aphids and scale insects: summer mineral oil or neem oil.',
          'Olive peacock spot: copper sprays in autumn and after rain.',
          'Fruit fly: bait traps and collecting fallen fruit.',
        ],
        harvest: [
          'Winter pruning improves airflow and yield; remove dead and crossing wood.',
          'Harvest at varietal maturity and avoid beating olive branches.',
        ],
      },
    },
  ],
}

const care: Record<Locale, CareTopic[]> = {
  ar: [
    {
      id: 'irrigation',
      title: 'إرشادات الري',
      intro: 'الري الصحيح يوفّر الماء ويمنع معظم الأمراض الفطرية.',
      points: [
        'اسقِ في الصباح الباكر أو المساء لتقليل التبخر.',
        'افحص رطوبة التربة بإصبعك على عمق 5 سم قبل الري.',
        'الري بالتنقيط يوفر 30–50٪ من الماء مقارنة بالغمر.',
        'تجنب بلل الأوراق لتقليل انتشار الفطريات.',
        'التربة الرملية تحتاج رياً أقل كمية وأكثر تكراراً من الطينية.',
      ],
    },
    {
      id: 'fertilization',
      title: 'إرشادات التسميد',
      intro: 'النيتروجين للنمو، والفوسفور للجذور والإزهار، والبوتاسيوم لجودة الثمار.',
      points: [
        'أجرِ تحليل تربة كل 2–3 سنوات قبل وضع برنامج التسميد.',
        'السماد العضوي المتحلل يحسّن بنية التربة ويحتفظ بالرطوبة.',
        'قسّم الأسمدة على دفعات صغيرة مع ماء الري (التسميد بالري).',
        'نقص النيتروجين: اصفرار الأوراق القديمة. نقص البوتاسيوم: احتراق حواف الأوراق.',
        'لا تضع السماد على تربة جافة أو ملاصقاً للساق.',
      ],
    },
    {
      id: 'treatments',
      title: 'الأدوية الزراعية والمكافحة',
      intro: 'ابدأ بالوقاية والمكافحة الحيوية، واستخدم المبيدات الكيميائية كحل أخير.',
      points: [
        'شخّص المشكلة جيداً قبل الرش؛ المبيد الخاطئ يضر ولا ينفع.',
        'المبيدات النحاسية والكبريت للأمراض الفطرية، وزيت النيم والصابون البوتاسي للحشرات الرخوة.',
        'التزم بالجرعة على الملصق وبفترة الأمان قبل الحصاد.',
        'بدّل المواد الفعالة لتجنب مقاومة الآفات.',
        'ارتدِ القفازات والكمامة ورش في الصباح بعيداً عن الرياح ووقت نشاط النحل.',
      ],
    },
  ],
  fr: [
    {
      id: 'irrigation',
      title: 'Conseils d’irrigation',
      intro: 'Une bonne irrigation économise l’eau et évite la plupart des maladies fongiques.',
      points: [
        'Arrosez tôt le matin ou le soir pour limiter l’évaporation.',
        'Vérifiez l’humidité du sol avec le doigt à 5 cm avant d’arroser.',
        'Le goutte-à-goutte économise 30 à 50 % d’eau par rapport à la submersion.',
        'Évitez de mouiller le feuillage pour limiter les champignons.',
        'Un sol sableux demande des arrosages plus fréquents mais moins abondants qu’un sol argileux.',
      ],
    },
    {
      id: 'fertilization',
      title: 'Conseils de fertilisation',
      intro: 'L’azote pour la croissance, le phosphore pour les racines et la floraison, le potassium pour la qualité des fruits.',
      points: [
        'Faites une analyse de sol tous les 2 à 3 ans avant d’établir un programme.',
        'Le compost bien décomposé améliore la structure du sol et retient l’humidité.',
        'Fractionnez les apports avec l’eau d’irrigation (fertigation).',
        'Carence en azote : jaunissement des vieilles feuilles. Carence en potassium : bords des feuilles brûlés.',
        'N’apportez pas d’engrais sur sol sec ni contre la tige.',
      ],
    },
    {
      id: 'treatments',
      title: 'Produits phytosanitaires et lutte',
      intro: 'Commencez par la prévention et la lutte biologique ; le chimique en dernier recours.',
      points: [
        'Identifiez bien le problème avant de traiter : un mauvais produit nuit sans soigner.',
        'Cuivre et soufre contre les champignons ; huile de neem et savon noir contre les insectes à corps mou.',
        'Respectez la dose de l’étiquette et le délai avant récolte.',
        'Alternez les matières actives pour éviter les résistances.',
        'Portez gants et masque, traitez le matin sans vent et hors activité des abeilles.',
      ],
    },
  ],
  en: [
    {
      id: 'irrigation',
      title: 'Irrigation guidelines',
      intro: 'Correct watering saves water and prevents most fungal diseases.',
      points: [
        'Water early in the morning or in the evening to reduce evaporation.',
        'Check soil moisture with your finger at 5 cm depth before watering.',
        'Drip irrigation saves 30–50% of water compared to flooding.',
        'Avoid wetting the leaves to limit fungal spread.',
        'Sandy soil needs smaller, more frequent watering than clay soil.',
      ],
    },
    {
      id: 'fertilization',
      title: 'Fertilization guidelines',
      intro: 'Nitrogen for growth, phosphorus for roots and flowering, potassium for fruit quality.',
      points: [
        'Run a soil test every 2–3 years before planning fertilization.',
        'Well-rotted compost improves soil structure and holds moisture.',
        'Split fertilizer into small doses through irrigation water (fertigation).',
        'Nitrogen deficiency: older leaves yellow. Potassium deficiency: scorched leaf edges.',
        'Never apply fertilizer to dry soil or against the stem.',
      ],
    },
    {
      id: 'treatments',
      title: 'Crop protection products',
      intro: 'Start with prevention and biological control; use chemicals as a last resort.',
      points: [
        'Identify the problem before spraying — the wrong product harms without helping.',
        'Copper and sulfur for fungal diseases; neem oil and potassium soap for soft-bodied insects.',
        'Follow the label dose and the pre-harvest interval.',
        'Rotate active ingredients to prevent resistance.',
        'Wear gloves and a mask, and spray in calm mornings outside bee activity.',
      ],
    },
  ],
}

export function getCropGuides(locale: Locale) {
  return crops[locale]
}

export function getCareTopics(locale: Locale) {
  return care[locale]
}

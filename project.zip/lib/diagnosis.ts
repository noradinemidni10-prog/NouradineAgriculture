import { z } from 'zod'

export const diagnosisSchema = z.object({
  isPlant: z.boolean(),
  plant: z.string().describe('Identified plant / crop name'),
  title: z.string().describe('Name of the disease, pest or deficiency, or "healthy"'),
  category: z.enum(['disease', 'pest', 'nutrient', 'healthy', 'unknown']),
  confidence: z.number().min(0).max(100),
  severity: z.enum(['none', 'low', 'medium', 'high']),
  summary: z.string(),
  symptoms: z.array(z.string()),
  causes: z.array(z.string()),
  organicTreatment: z.array(z.string()),
  chemicalTreatment: z.array(z.string()),
  irrigation: z.array(z.string()),
  fertilization: z.array(z.string()),
  prevention: z.array(z.string()),
})

export type Diagnosis = z.infer<typeof diagnosisSchema>

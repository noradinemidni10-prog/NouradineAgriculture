import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Cairo } from 'next/font/google'
import { cookies } from 'next/headers'
import { AppShell } from '@/components/app-shell'
import { LocaleProvider } from '@/components/locale-provider'
import { DEFAULT_LOCALE, LOCALE_COOKIE, LOCALE_META, isLocale } from '@/lib/i18n/dictionaries'
import './globals.css'

const cairo = Cairo({ subsets: ['arabic', 'latin'], variable: '--font-cairo', display: 'swap' })

export const metadata: Metadata = {
  title: 'أكاديمية نورالدين للزراعة – Nouradine',
  description:
    'Nouradine Agriculture Academy: AI farming assistant, plant disease diagnosis, pest and deficiency detection, irrigation and fertilization guides in Arabic, French and English.',
  generator: 'v0.app',
  applicationName: 'Nouradine',
  appleWebApp: { capable: true, title: 'Nouradine', statusBarStyle: 'default' },
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icons/icon-192x192.png', sizes: '192x192', type: 'image/png' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#2f6b45',
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
}

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const stored = (await cookies()).get(LOCALE_COOKIE)?.value
  const locale = isLocale(stored) ? stored : DEFAULT_LOCALE

  return (
    <html lang={locale} dir={LOCALE_META[locale].dir} className={`${cairo.variable} bg-background`}>
      <body className="font-sans antialiased">
        <LocaleProvider initialLocale={locale}>
          <AppShell>{children}</AppShell>
        </LocaleProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}

import { convertToModelMessages, createUIMessageStreamResponse, streamText, toUIMessageStream, type UIMessage } from 'ai'
import { LANGUAGE_NAMES, isLocale, DEFAULT_LOCALE } from '@/lib/i18n/dictionaries'

export const maxDuration = 60

export async function POST(req: Request) {
  const { messages, locale: rawLocale }: { messages: UIMessage[]; locale?: string } = await req.json()
  const locale = isLocale(rawLocale) ? rawLocale : DEFAULT_LOCALE
  const language = LANGUAGE_NAMES[locale]

  const result = streamText({
    model: 'google/gemini-3-flash',
    system: `You are "Nouradine", the friendly expert farming assistant of "Nouradine Agriculture Academy".
Always reply in ${language}${locale === 'ar' ? ' (Modern Standard Arabic, simple and clear)' : ''}, regardless of the language of earlier messages, unless the user explicitly asks for another language.
Help farmers and gardeners with: irrigation schedules, fertilization programs (NPK, micronutrients, organic options), plant diseases, pests and insects, nutrient deficiencies, organic and chemical treatments (mention active ingredients, dose ranges and pre-harvest intervals, and advise following the label), growing tomatoes, peppers and fruit trees, soil, climate and seasons (with attention to Mediterranean and North African conditions).
Be practical and concise. Use short headings and bullet lists in Markdown. Ask a short follow-up question when key info (crop, stage, climate, symptoms) is missing.
Never invent product brand names. Politely decline topics unrelated to agriculture.`,
    messages: await convertToModelMessages(messages),
  })

  return createUIMessageStreamResponse({
    stream: toUIMessageStream({ stream: result.stream, originalMessages: messages }),
  })
}

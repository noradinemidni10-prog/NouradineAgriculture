import { generateText } from 'ai'
import { z } from 'zod'
import { DEFAULT_LOCALE, LANGUAGE_NAMES, isLocale } from '@/lib/i18n/dictionaries'

export const maxDuration = 60

const requestSchema = z.object({ query: z.string().trim().min(2).max(300), locale: z.string().optional() })

export async function POST(req: Request) {
  const parsed = requestSchema.safeParse(await req.json())
  if (!parsed.success) return Response.json({ error: 'invalid_request' }, { status: 400 })
  const locale = isLocale(parsed.data.locale) ? parsed.data.locale : DEFAULT_LOCALE

  try {
    const result = await generateText({
      model: 'perplexity/sonar',
      system: `You are an agricultural research assistant. Search the web and answer only agriculture-related questions with up-to-date, practical information.
Answer in ${LANGUAGE_NAMES[locale]}. Use concise Markdown with short headings and bullet points. Do not include a sources list; sources are shown separately.`,
      prompt: parsed.data.query,
    })

    const seen = new Set<string>()
    const sources = result.sources
      .filter((s) => s.sourceType === 'url')
      .map((s) => ({ url: s.url, title: s.title || new URL(s.url).hostname }))
      .filter((s) => (seen.has(s.url) ? false : (seen.add(s.url), true)))
      .slice(0, 8)

    return Response.json({ answer: result.text.replace(/\[\d+\]/g, ''), sources })
  } catch (error) {
    console.error('[v0] search failed', error)
    return Response.json({ error: 'search_failed' }, { status: 500 })
  }
}

import { generateText, Output } from 'ai'
import { z } from 'zod'
import { DEFAULT_LOCALE, LANGUAGE_NAMES, isLocale } from '@/lib/i18n/dictionaries'
import { diagnosisSchema } from '@/lib/diagnosis'

export const maxDuration = 60

const requestSchema = z.object({
  image: z.string().startsWith('data:image/').max(14_000_000),
  locale: z.string().optional(),
  mode: z.enum(['auto', 'disease', 'pest', 'nutrient']).default('auto'),
  crop: z.string().max(80).optional(),
  notes: z.string().max(500).optional(),
})

const focus = {
  auto: 'Determine whether the problem is a disease, a pest/insect, a nutrient deficiency, or whether the plant is healthy.',
  disease: 'Focus on fungal, bacterial and viral plant diseases.',
  pest: 'Focus on pests, insects, mites and their damage.',
  nutrient: 'Focus on nutrient deficiencies and toxicities (N, P, K, Ca, Mg, Fe, Zn, Mn, B...).',
}

export async function POST(req: Request) {
  const parsed = requestSchema.safeParse(await req.json())
  if (!parsed.success) return Response.json({ error: 'invalid_request' }, { status: 400 })

  const { image, mode, crop, notes } = parsed.data
  const locale = isLocale(parsed.data.locale) ? parsed.data.locale : DEFAULT_LOCALE

  try {
    const { output } = await generateText({
      model: 'google/gemini-3-flash',
      output: Output.object({ schema: diagnosisSchema }),
      system: `You are an expert plant pathologist, entomologist and agronomist. Analyze the plant photo carefully.
${focus[mode]}
Write every text field in ${LANGUAGE_NAMES[locale]}. Keep each list item short and actionable.
For chemical treatments name active ingredients (not brands), typical dose ranges and the need to respect the pre-harvest interval.
If the image does not show a plant, set isPlant to false and leave lists empty.`,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: `Crop: ${crop || 'unknown'}\nGrower notes: ${notes || 'none'}` },
            { type: 'file', data: image, mediaType: image.slice(5, image.indexOf(';')) },
          ],
        },
      ],
    })
    return Response.json(output)
  } catch (error) {
    console.error('[v0] diagnose failed', error)
    return Response.json({ error: 'analysis_failed' }, { status: 500 })
  }
}

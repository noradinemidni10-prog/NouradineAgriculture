import { GuidesView } from '@/components/guides/guides-view'

export default function GuidesPage() {
  return <GuidesView />
}

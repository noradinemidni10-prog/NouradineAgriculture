import { DiagnoseView } from '@/components/diagnose/diagnose-view'

export default function DiagnosePage() {
  return <DiagnoseView />
}

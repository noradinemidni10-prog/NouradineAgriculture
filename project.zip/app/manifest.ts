import type { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: '/',
    name: 'أكاديمية نورالدين للزراعة – Nouradine',
    short_name: 'Nouradine',
    description: 'Smart farming assistant: chat, plant diagnosis, growing guides and agricultural search.',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#fbfaf5',
    theme_color: '#2f6b45',
    lang: 'ar',
    dir: 'auto',
    categories: ['education', 'productivity', 'lifestyle'],
    icons: [
      { src: '/icons/icon-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icons/icon-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icons/maskable-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  }
}

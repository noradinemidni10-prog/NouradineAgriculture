'use client'

import { Languages } from 'lucide-react'
import { LOCALES, LOCALE_META } from '@/lib/i18n/dictionaries'
import { cn } from '@/lib/utils'
import { useLocale } from './locale-provider'

export function LanguageSwitcher({ className }: { className?: string }) {
  const { locale, setLocale, t } = useLocale()

  return (
    <div
      role="radiogroup"
      aria-label={t.app.language}
      className={cn('flex items-center gap-0.5 rounded-full border bg-card p-0.5 shadow-xs', className)}
    >
      <Languages className="mx-1.5 size-4 text-muted-foreground" aria-hidden="true" />
      {LOCALES.map((l) => {
        const active = l === locale
        return (
          <button
            key={l}
            type="button"
            role="radio"
            aria-checked={active}
            lang={l}
            title={LOCALE_META[l].label}
            onClick={() => setLocale(l)}
            className={cn(
              'min-w-9 rounded-full px-2.5 py-1 text-xs font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-ring',
              active ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground',
            )}
          >
            <span aria-hidden="true">{LOCALE_META[l].short}</span>
            <span className="sr-only">{LOCALE_META[l].label}</span>
          </button>
        )
      })}
    </div>
  )
}

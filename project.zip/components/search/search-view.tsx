'use client'

import { useState } from 'react'
import ReactMarkdown from 'react-markdown'
import { ExternalLink, Globe, Loader2, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useLocale } from '@/components/locale-provider'

interface SearchResult {
  answer: string
  sources: { url: string; title: string }[]
}

export function SearchView() {
  const { t, locale } = useLocale()
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [result, setResult] = useState<SearchResult | null>(null)

  const run = async (q: string) => {
    const value = q.trim()
    if (value.length < 2 || loading) return
    setQuery(value)
    setLoading(true)
    setError(false)
    setResult(null)
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: value, locale }),
      })
      if (!res.ok) throw new Error()
      setResult(await res.json())
    } catch {
      setError(true)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <header>
        <h1 className="text-2xl font-extrabold sm:text-3xl">{t.search.title}</h1>
        <p className="mt-2 leading-relaxed text-muted-foreground">{t.search.subtitle}</p>
      </header>

      <form
        role="search"
        className="mt-6 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault()
          run(query)
        }}
      >
        <label htmlFor="search-q" className="sr-only">{t.search.placeholder}</label>
        <Input
          id="search-q"
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t.search.placeholder}
          maxLength={300}
          className="h-12 rounded-full bg-card px-5"
        />
        <Button type="submit" size="lg" className="h-12 rounded-full" disabled={loading || query.trim().length < 2}>
          {loading ? <Loader2 className="animate-spin" aria-hidden="true" /> : <Search aria-hidden="true" />}
          <span className="hidden sm:inline">{loading ? t.search.searching : t.search.button}</span>
        </Button>
      </form>

      <div className="mt-4 flex flex-wrap gap-2">
        {t.search.examples.map((ex) => (
          <button
            key={ex}
            type="button"
            onClick={() => run(ex)}
            className="rounded-full border bg-card px-3 py-1.5 text-sm transition-colors hover:border-primary/50 hover:bg-secondary"
          >
            {ex}
          </button>
        ))}
      </div>

      <section aria-live="polite" className="mt-8">
        {error && <p role="alert" className="text-destructive">{t.search.error}</p>}
        {loading && (
          <div className="flex items-center gap-3 rounded-3xl border bg-card p-6 text-muted-foreground">
            <Loader2 className="size-5 animate-spin text-primary" aria-hidden="true" />
            {t.search.searching}
          </div>
        )}
        {!loading && !result && !error && (
          <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed p-10 text-center text-muted-foreground">
            <Globe className="size-8" aria-hidden="true" />
            <p>{t.search.empty}</p>
          </div>
        )}
        {result && (
          <article className="flex flex-col gap-6 rounded-3xl border bg-card p-5 sm:p-6">
            <div className="prose-chat">
              <ReactMarkdown>{result.answer}</ReactMarkdown>
            </div>
            {result.sources.length > 0 && (
              <div>
                <h2 className="font-semibold">{t.search.sources}</h2>
                <ul className="mt-2 grid gap-2 sm:grid-cols-2">
                  {result.sources.map((s) => (
                    <li key={s.url}>
                      <a
                        href={s.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 rounded-xl border p-3 text-sm transition-colors hover:bg-secondary"
                      >
                        <ExternalLink className="size-4 shrink-0 text-primary" aria-hidden="true" />
                        <span className="min-w-0">
                          <span className="block truncate font-medium">{s.title}</span>
                          <span className="block truncate text-xs text-muted-foreground" dir="ltr">{new URL(s.url).hostname}</span>
                        </span>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </article>
        )}
      </section>
    </div>
  )
}

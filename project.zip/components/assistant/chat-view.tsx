'use client'

import { useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import ReactMarkdown from 'react-markdown'
import { RotateCcw, SendHorizontal, Square } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { AssistantAvatar } from '@/components/assistant-avatar'
import { useLocale } from '@/components/locale-provider'
import { cn } from '@/lib/utils'

export function ChatView() {
  const { t, locale } = useLocale()
  const localeRef = useRef(locale)
  localeRef.current = locale

  const [transport] = useState(
    () => new DefaultChatTransport({ api: '/api/chat', body: () => ({ locale: localeRef.current }) }),
  )
  const { messages, sendMessage, status, stop, error, regenerate, setMessages } = useChat({ transport })
  const [input, setInput] = useState('')
  const bottomRef = useRef<HTMLDivElement>(null)
  const searchParams = useSearchParams()
  const prefilled = useRef(false)

  useEffect(() => {
    const q = searchParams.get('q')
    if (q && !prefilled.current) {
      prefilled.current = true
      setInput(q)
    }
  }, [searchParams])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages, status])

  const busy = status === 'submitted' || status === 'streaming'

  const submit = (text: string) => {
    const value = text.trim()
    if (!value || busy) return
    sendMessage({ text: value })
    setInput('')
  }

  return (
    <div className="mx-auto flex h-[calc(100dvh-4rem-5rem)] max-w-3xl flex-col px-4 lg:h-[calc(100dvh-4rem-4.5rem)]">
      <div className="flex items-center gap-3 border-b py-4">
        <AssistantAvatar className="size-11" />
        <div className="min-w-0 flex-1">
          <h1 className="truncate font-bold">{t.assistant.title}</h1>
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="size-2 rounded-full bg-primary" aria-hidden="true" />
            {t.assistant.status}
          </p>
        </div>
        {messages.length > 0 && (
          <Button variant="ghost" size="sm" onClick={() => setMessages([])} disabled={busy}>
            <RotateCcw aria-hidden="true" />
            {t.assistant.clear}
          </Button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto py-6" aria-live="polite">
        <div className="flex flex-col gap-5">
          <AssistantBubble>
            <p>{t.assistant.greeting}</p>
          </AssistantBubble>

          {messages.length === 0 && (
            <div className="flex flex-col gap-2">
              <p className="text-sm font-medium text-muted-foreground">{t.assistant.suggestionsTitle}</p>
              <div className="flex flex-wrap gap-2">
                {t.assistant.suggestions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => submit(s)}
                    className="rounded-full border bg-card px-3 py-1.5 text-start text-sm transition-colors hover:border-primary/50 hover:bg-secondary"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m) => {
            const text = m.parts.map((p) => (p.type === 'text' ? p.text : '')).join('')
            if (m.role === 'user') {
              return (
                <div key={m.id} className="flex justify-end">
                  <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-ee-sm bg-primary px-4 py-2.5 text-primary-foreground">
                    <span className="sr-only">{t.assistant.you}: </span>
                    {text}
                  </div>
                </div>
              )
            }
            return (
              <AssistantBubble key={m.id}>
                <div className="prose-chat">
                  <ReactMarkdown>{text}</ReactMarkdown>
                </div>
              </AssistantBubble>
            )
          })}

          {status === 'submitted' && (
            <AssistantBubble>
              <p className="animate-pulse text-muted-foreground">{t.assistant.thinking}</p>
            </AssistantBubble>
          )}

          {error && (
            <div className="flex items-center gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
              <span className="flex-1">{t.assistant.error}</span>
              <Button size="sm" variant="outline" onClick={() => regenerate()}>
                {t.assistant.retry}
              </Button>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </div>

      <form
        className="flex items-end gap-2 border-t py-3"
        onSubmit={(e) => {
          e.preventDefault()
          submit(input)
        }}
      >
        <label htmlFor="chat-input" className="sr-only">
          {t.assistant.placeholder}
        </label>
        <Textarea
          id="chat-input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !(e.nativeEvent.isComposing || e.keyCode === 229)) {
              e.preventDefault()
              submit(input)
            }
          }}
          placeholder={t.assistant.placeholder}
          rows={1}
          className="max-h-40 min-h-11 resize-none rounded-2xl bg-card"
        />
        {busy ? (
          <Button type="button" size="icon" variant="outline" className="size-11 rounded-full" onClick={() => stop()}>
            <Square aria-hidden="true" />
            <span className="sr-only">{t.assistant.stop}</span>
          </Button>
        ) : (
          <Button type="submit" size="icon" className="size-11 rounded-full" disabled={!input.trim()}>
            <SendHorizontal className="rtl:-scale-x-100" aria-hidden="true" />
            <span className="sr-only">{t.assistant.send}</span>
          </Button>
        )}
      </form>
    </div>
  )
}

function AssistantBubble({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3">
      <AssistantAvatar className="size-8 ring-1 ring-offset-1" />
      <div className={cn('max-w-[85%] rounded-2xl rounded-ss-sm border bg-card px-4 py-2.5 leading-relaxed')}>{children}</div>
    </div>
  )
}

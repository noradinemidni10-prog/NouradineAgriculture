'use client'

import Image from 'next/image'
import { Droplets, FlaskConical, TestTube } from 'lucide-react'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useLocale } from '@/components/locale-provider'
import { getCareTopics, getCropGuides, type SectionId } from '@/lib/i18n/guides'

const SECTION_ORDER: SectionId[] = ['planting', 'irrigation', 'fertilization', 'problems', 'harvest']
const CARE_ICONS = { irrigation: Droplets, fertilization: TestTube, treatments: FlaskConical }

export function GuidesView() {
  const { t, locale, dir } = useLocale()
  const crops = getCropGuides(locale)
  const care = getCareTopics(locale)

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <header className="max-w-2xl">
        <h1 className="text-2xl font-extrabold sm:text-3xl">{t.guides.title}</h1>
        <p className="mt-2 leading-relaxed text-muted-foreground">{t.guides.subtitle}</p>
      </header>

      <Tabs defaultValue="crops" dir={dir} className="mt-6">
        <TabsList className="h-auto flex-wrap">
          <TabsTrigger value="crops">{t.guides.cropsTab}</TabsTrigger>
          <TabsTrigger value="care">{t.guides.careTab}</TabsTrigger>
        </TabsList>

        <TabsContent value="crops" className="mt-6">
          <Tabs defaultValue={crops[0].id} dir={dir}>
            <TabsList className="h-auto flex-wrap">
              {crops.map((c) => (
                <TabsTrigger key={c.id} value={c.id}>{c.name}</TabsTrigger>
              ))}
            </TabsList>
            {crops.map((c) => (
              <TabsContent key={c.id} value={c.id} className="mt-4">
                <article className="grid gap-6 rounded-3xl border bg-card p-4 sm:p-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
                  <div className="flex flex-col gap-3">
                    <div className="relative aspect-[4/3] overflow-hidden rounded-2xl">
                      <Image src={c.image} alt={c.name} fill sizes="(max-width: 1024px) 100vw, 440px" className="object-cover" />
                    </div>
                    <h2 className="text-xl font-bold">{c.name}</h2>
                    <p className="leading-relaxed text-muted-foreground">{c.summary}</p>
                  </div>
                  <Accordion type="multiple" defaultValue={['planting']}>
                    {SECTION_ORDER.map((s) => (
                      <AccordionItem key={s} value={s}>
                        <AccordionTrigger className="text-base font-semibold">{t.guides.sections[s]}</AccordionTrigger>
                        <AccordionContent>
                          <ul className="flex list-disc flex-col gap-2 ps-5 leading-relaxed">
                            {c.sections[s].map((p) => (
                              <li key={p}>{p}</li>
                            ))}
                          </ul>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </article>
              </TabsContent>
            ))}
          </Tabs>
        </TabsContent>

        <TabsContent value="care" className="mt-6">
          <div className="grid gap-4 lg:grid-cols-3">
            {care.map((topic) => {
              const Icon = CARE_ICONS[topic.id]
              return (
                <article key={topic.id} className="rounded-3xl border bg-card p-5">
                  <span className="flex size-11 items-center justify-center rounded-xl bg-secondary text-primary">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                  <h2 className="mt-3 text-lg font-bold">{topic.title}</h2>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{topic.intro}</p>
                  <ul className="mt-3 flex list-disc flex-col gap-2 ps-5 text-sm leading-relaxed">
                    {topic.points.map((p) => (
                      <li key={p}>{p}</li>
                    ))}
                  </ul>
                </article>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Crown, Home, MessageCircle, ScanLine, Search, BookOpen, Sprout } from 'lucide-react'
import { cn } from '@/lib/utils'
import { LanguageSwitcher } from './language-switcher'
import { InstallButton } from './install-button'
import { ServiceWorkerRegister } from './service-worker-register'
import { useLocale } from './locale-provider'

const NAV = [
  { href: '/', key: 'home', icon: Home },
  { href: '/assistant', key: 'assistant', icon: MessageCircle },
  { href: '/diagnose', key: 'diagnose', icon: ScanLine },
  { href: '/guides', key: 'guides', icon: BookOpen },
  { href: '/search', key: 'search', icon: Search },
  { href: '/premium', key: 'premium', icon: Crown },
] as const

export function AppShell({ children }: { children: React.ReactNode }) {
  const { t } = useLocale()
  const pathname = usePathname()
  const isActive = (href: string) => (href === '/' ? pathname === '/' : pathname.startsWith(href))

  return (
    <div className="flex min-h-dvh flex-col">
      <ServiceWorkerRegister />
      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur supports-[backdrop-filter]:bg-background/70">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
          <Link href="/" className="flex min-w-0 items-center gap-2 font-bold">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <Sprout className="size-5" aria-hidden="true" />
            </span>
            <span className="truncate text-sm leading-tight sm:text-base">
              <span className="block truncate">{t.app.name}</span>
              <span className="block text-xs font-medium text-muted-foreground">{t.app.short}</span>
            </span>
          </Link>
          <nav aria-label="Main" className="ms-auto hidden items-center gap-1 lg:flex">
            {NAV.map(({ href, key }) => (
              <Link
                key={href}
                href={href}
                aria-current={isActive(href) ? 'page' : undefined}
                className={cn(
                  'rounded-full px-3 py-1.5 text-sm font-medium transition-colors',
                  isActive(href) ? 'bg-secondary text-secondary-foreground' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {t.nav[key]}
              </Link>
            ))}
          </nav>
          <div className="ms-auto flex items-center gap-2 lg:ms-2">
            <InstallButton />
            <LanguageSwitcher />
          </div>
        </div>
      </header>

      <main className="flex-1 pb-24 lg:pb-0">{children}</main>

      <footer className="hidden border-t py-6 text-center text-xs text-muted-foreground lg:block">{t.app.footer}</footer>

      <nav
        aria-label="Mobile"
        className="fixed inset-x-0 bottom-0 z-40 border-t bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
      >
        <ul className="mx-auto grid max-w-lg grid-cols-6">
          {NAV.map(({ href, key, icon: Icon }) => (
            <li key={href}>
              <Link
                href={href}
                aria-current={isActive(href) ? 'page' : undefined}
                className={cn(
                  'flex flex-col items-center gap-1 py-2 text-[11px] font-medium',
                  isActive(href) ? 'text-primary' : 'text-muted-foreground',
                )}
              >
                <Icon className="size-5" aria-hidden="true" />
                <span className="truncate">{t.nav[key]}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  )
}

'use client'

import { Sprout } from 'lucide-react'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { cn } from '@/lib/utils'
import { useLocale } from './locale-provider'

export const ASSISTANT_PHOTO = '/images/nouradine.jpg'

export function AssistantAvatar({ className }: { className?: string }) {
  const { t } = useLocale()
  return (
    <Avatar className={cn('size-10 ring-2 ring-accent ring-offset-2 ring-offset-background', className)}>
      <AvatarImage src={ASSISTANT_PHOTO} alt={t.app.short} className="object-cover" />
      <AvatarFallback className="bg-primary text-primary-foreground">
        <Sprout className="size-1/2" aria-hidden="true" />
      </AvatarFallback>
    </Avatar>
  )
}

'use client'

import { useRef, useState } from 'react'
import { Camera, Loader2, ScanLine } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { useLocale } from '@/components/locale-provider'
import type { Diagnosis } from '@/lib/diagnosis'
import { cn } from '@/lib/utils'
import { DiagnosisResult } from './diagnosis-result'

type Mode = 'auto' | 'disease' | 'pest' | 'nutrient'
const MODES: Mode[] = ['auto', 'disease', 'pest', 'nutrient']
const MAX_BYTES = 10 * 1024 * 1024

async function toResizedDataUrl(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file)
  const scale = Math.min(1, 1280 / Math.max(bitmap.width, bitmap.height))
  const canvas = document.createElement('canvas')
  canvas.width = Math.round(bitmap.width * scale)
  canvas.height = Math.round(bitmap.height * scale)
  canvas.getContext('2d')?.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
  return canvas.toDataURL('image/jpeg', 0.85)
}

export function DiagnoseView() {
  const { t, locale } = useLocale()
  const fileRef = useRef<HTMLInputElement>(null)
  const [image, setImage] = useState<string | null>(null)
  const [mode, setMode] = useState<Mode>('auto')
  const [crop, setCrop] = useState('')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<Diagnosis | null>(null)

  const onFile = async (file?: File) => {
    if (!file) return
    setError(null)
    setResult(null)
    if (file.size > MAX_BYTES) {
      setError(t.diagnose.tooLarge)
      return
    }
    setImage(await toResizedDataUrl(file))
  }

  const analyze = async () => {
    if (!image) return
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const res = await fetch('/api/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image, mode, crop, notes, locale }),
      })
      if (!res.ok) throw new Error()
      setResult(await res.json())
    } catch {
      setError(t.diagnose.error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <header className="max-w-2xl">
        <h1 className="text-balance text-2xl font-extrabold sm:text-3xl">{t.diagnose.title}</h1>
        <p className="mt-2 leading-relaxed text-muted-foreground">{t.diagnose.subtitle}</p>
      </header>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <section className="flex flex-col gap-5 rounded-3xl border bg-card p-5">
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="sr-only"
            id="plant-photo"
            onChange={(e) => onFile(e.target.files?.[0])}
          />
          <label
            htmlFor="plant-photo"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault()
              onFile(e.dataTransfer.files?.[0])
            }}
            className={cn(
              'relative flex aspect-[4/3] cursor-pointer flex-col items-center justify-center gap-2 overflow-hidden rounded-2xl border-2 border-dashed bg-muted/40 text-center transition-colors hover:border-primary/60',
              image && 'border-solid',
            )}
          >
            {image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={image} alt="" className="absolute inset-0 size-full object-cover" />
            ) : (
              <>
                <span className="flex size-14 items-center justify-center rounded-full bg-secondary text-primary">
                  <Camera className="size-6" aria-hidden="true" />
                </span>
                <span className="font-semibold">{t.diagnose.upload}</span>
                <span className="text-xs text-muted-foreground">{t.diagnose.dropHint}</span>
              </>
            )}
          </label>
          {image && (
            <Button variant="outline" onClick={() => fileRef.current?.click()}>
              {t.diagnose.change}
            </Button>
          )}

          <fieldset>
            <legend className="mb-2 text-sm font-medium">{t.diagnose.modeLabel}</legend>
            <div className="grid grid-cols-2 gap-2">
              {MODES.map((m) => (
                <button
                  key={m}
                  type="button"
                  aria-pressed={mode === m}
                  onClick={() => setMode(m)}
                  className={cn(
                    'rounded-xl border px-3 py-2 text-sm font-medium transition-colors',
                    mode === m ? 'border-primary bg-primary text-primary-foreground' : 'hover:bg-secondary',
                  )}
                >
                  {t.diagnose.modes[m]}
                </button>
              ))}
            </div>
          </fieldset>

          <div className="flex flex-col gap-2">
            <label htmlFor="crop" className="text-sm font-medium">{t.diagnose.cropLabel}</label>
            <Input id="crop" value={crop} onChange={(e) => setCrop(e.target.value)} placeholder={t.diagnose.cropPlaceholder} maxLength={80} />
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="notes" className="text-sm font-medium">{t.diagnose.notesLabel}</label>
            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder={t.diagnose.notesPlaceholder} maxLength={500} rows={2} />
          </div>

          <Button size="lg" className="rounded-full" disabled={!image || loading} onClick={analyze}>
            {loading ? <Loader2 className="animate-spin" aria-hidden="true" /> : <ScanLine aria-hidden="true" />}
            {loading ? t.diagnose.analyzing : t.diagnose.analyze}
          </Button>
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        </section>

        <section aria-live="polite" className="min-h-64">
          {result ? (
            <DiagnosisResult result={result} />
          ) : (
            <div className="flex h-full min-h-64 flex-col items-center justify-center gap-3 rounded-3xl border border-dashed p-8 text-center text-muted-foreground">
              {loading ? <Loader2 className="size-8 animate-spin text-primary" aria-hidden="true" /> : <ScanLine className="size-8" aria-hidden="true" />}
              <p className="max-w-xs">{loading ? t.diagnose.analyzing : t.diagnose.empty}</p>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}

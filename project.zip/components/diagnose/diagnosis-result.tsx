'use client'

import Link from 'next/link'
import { AlertTriangle, Bug, Droplets, FlaskConical, Leaf, MessageCircle, ShieldCheck, Sprout, Stethoscope, TestTube } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useLocale } from '@/components/locale-provider'
import type { Diagnosis } from '@/lib/diagnosis'
import { cn } from '@/lib/utils'

const severityStyle = {
  none: 'bg-secondary text-secondary-foreground',
  low: 'bg-secondary text-secondary-foreground',
  medium: 'bg-accent text-accent-foreground',
  high: 'bg-destructive text-white',
}

export function DiagnosisResult({ result }: { result: Diagnosis }) {
  const { t } = useLocale()
  const d = t.diagnose

  if (!result.isPlant) {
    return (
      <div className="flex items-center gap-3 rounded-3xl border bg-card p-6">
        <AlertTriangle className="size-6 shrink-0 text-accent" aria-hidden="true" />
        <p>{d.notPlant}</p>
      </div>
    )
  }

  const blocks = [
    { key: 'symptoms', label: d.symptoms, items: result.symptoms, icon: Stethoscope },
    { key: 'causes', label: d.causes, items: result.causes, icon: Bug },
    { key: 'organic', label: d.organic, items: result.organicTreatment, icon: Leaf },
    { key: 'chemical', label: d.chemical, items: result.chemicalTreatment, icon: FlaskConical },
    { key: 'irrigation', label: d.irrigation, items: result.irrigation, icon: Droplets },
    { key: 'fertilization', label: d.fertilization, items: result.fertilization, icon: TestTube },
    { key: 'prevention', label: d.prevention, items: result.prevention, icon: ShieldCheck },
  ].filter((b) => b.items.length > 0)

  const question = `${result.plant}: ${result.title}`

  return (
    <article className="flex flex-col gap-4 rounded-3xl border bg-card p-5 sm:p-6">
      <header className="flex flex-col gap-3">
        <p className="text-sm font-medium text-muted-foreground">{d.resultTitle}</p>
        <div className="flex items-start gap-3">
          <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-secondary text-primary">
            <Sprout className="size-5" aria-hidden="true" />
          </span>
          <div>
            <h2 className="text-xl font-bold">{result.title}</h2>
            <p className="text-sm text-muted-foreground">{result.plant}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline">{d.category}: {d.categories[result.category]}</Badge>
          <Badge className={cn(severityStyle[result.severity])}>{d.severity}: {d.severities[result.severity]}</Badge>
          <Badge variant="outline">{d.confidence}: {Math.round(result.confidence)}%</Badge>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-muted" role="presentation">
          <div className="h-full rounded-full bg-primary" style={{ width: `${Math.round(result.confidence)}%` }} />
        </div>
        <p className="leading-relaxed">{result.summary}</p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        {blocks.map(({ key, label, items, icon: Icon }) => (
          <section key={key} className="rounded-2xl bg-muted/50 p-4">
            <h3 className="flex items-center gap-2 font-semibold">
              <Icon className="size-4 text-primary" aria-hidden="true" />
              {label}
            </h3>
            <ul className="mt-2 flex list-disc flex-col gap-1.5 ps-5 text-sm leading-relaxed">
              {items.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </section>
        ))}
      </div>

      <p className="flex items-start gap-2 text-xs text-muted-foreground">
        <AlertTriangle className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
        {d.disclaimer}
      </p>
      <Button asChild variant="outline" className="w-fit rounded-full">
        <Link href={`/assistant?q=${encodeURIComponent(question)}`}>
          <MessageCircle aria-hidden="true" />
          {d.askAssistant}
        </Link>
      </Button>
    </article>
  )
}

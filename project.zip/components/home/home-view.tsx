'use client'

import Image from 'next/image'
import Link from 'next/link'
import { BookOpen, Bug, Droplets, Globe, MessageCircle, ScanLine } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { AssistantAvatar } from '@/components/assistant-avatar'
import { useLocale } from '@/components/locale-provider'

const FEATURE_META = [
  { icon: MessageCircle, href: '/assistant' },
  { icon: ScanLine, href: '/diagnose' },
  { icon: Bug, href: '/diagnose' },
  { icon: Droplets, href: '/guides' },
  { icon: BookOpen, href: '/guides' },
  { icon: Globe, href: '/search' },
]

export function HomeView() {
  const { t } = useLocale()

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 lg:py-12">
      <section className="relative overflow-hidden rounded-3xl bg-primary text-primary-foreground">
        <Image
          src="/images/hero-farm.jpg"
          alt=""
          fill
          priority
          sizes="(max-width: 1200px) 100vw, 1152px"
          className="object-cover opacity-30"
        />
        <div className="relative flex flex-col gap-6 p-6 sm:p-10 lg:max-w-2xl lg:p-14">
          <Badge className="w-fit bg-accent text-accent-foreground">{t.home.badge}</Badge>
          <h1 className="text-pretty text-3xl font-extrabold leading-tight sm:text-4xl lg:text-5xl">{t.home.title}</h1>
          <p className="text-pretty text-base leading-relaxed text-primary-foreground/90 sm:text-lg">{t.home.subtitle}</p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="rounded-full bg-accent text-accent-foreground hover:bg-accent/90">
              <Link href="/assistant">
                <MessageCircle aria-hidden="true" />
                {t.home.ctaChat}
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full border-primary-foreground/40 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
            >
              <Link href="/diagnose">
                <ScanLine aria-hidden="true" />
                {t.home.ctaDiagnose}
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section aria-labelledby="meet" className="mt-8 flex flex-col items-center gap-5 rounded-3xl border bg-card p-6 text-center sm:flex-row sm:text-start">
        <AssistantAvatar className="size-24" />
        <div className="flex-1">
          <h2 id="meet" className="text-xl font-bold">{t.home.meetTitle}</h2>
          <p className="mt-1 leading-relaxed text-muted-foreground">{t.home.meetText}</p>
        </div>
        <Button asChild className="rounded-full">
          <Link href="/assistant">{t.home.ctaChat}</Link>
        </Button>
      </section>

      <section aria-labelledby="features" className="mt-12">
        <h2 id="features" className="text-balance text-2xl font-bold">{t.home.featuresTitle}</h2>
        <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {t.home.features.map((f, i) => {
            const { icon: Icon, href } = FEATURE_META[i]
            return (
              <li key={f.title}>
                <Link
                  href={href}
                  className="flex h-full gap-4 rounded-2xl border bg-card p-5 transition-colors hover:border-primary/40 hover:bg-secondary/40"
                >
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-secondary text-primary">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                  <span>
                    <span className="block font-semibold">{f.title}</span>
                    <span className="mt-1 block text-sm leading-relaxed text-muted-foreground">{f.desc}</span>
                  </span>
                </Link>
              </li>
            )
          })}
        </ul>
      </section>
    </div>
  )
}

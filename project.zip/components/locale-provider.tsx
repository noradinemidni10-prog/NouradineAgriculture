'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { dictionaries, LOCALE_COOKIE, LOCALE_META, type Dictionary, type Locale } from '@/lib/i18n/dictionaries'

interface LocaleContextValue {
  locale: Locale
  dir: 'rtl' | 'ltr'
  t: Dictionary
  setLocale: (locale: Locale) => void
}

const LocaleContext = createContext<LocaleContextValue | null>(null)

export function LocaleProvider({ initialLocale, children }: { initialLocale: Locale; children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(initialLocale)

  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next)
    document.cookie = `${LOCALE_COOKIE}=${next}; path=/; max-age=31536000; samesite=lax`
    document.documentElement.lang = next
    document.documentElement.dir = LOCALE_META[next].dir
    document.title = dictionaries[next].app.name
  }, [])

  const value = useMemo(
    () => ({ locale, dir: LOCALE_META[locale].dir, t: dictionaries[locale], setLocale }),
    [locale, setLocale],
  )

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>
}

export function useLocale() {
  const ctx = useContext(LocaleContext)
  if (!ctx) throw new Error('useLocale must be used within LocaleProvider')
  return ctx
}

'use client'

import { useState } from 'react'
import { Check, Crown, Info } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useLocale } from '@/components/locale-provider'

export function PremiumView() {
  const { t } = useLocale()
  const p = t.premium
  const [notice, setNotice] = useState(false)

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 lg:py-12">
      <header className="mx-auto max-w-2xl text-center">
        <h1 className="text-balance text-2xl font-extrabold sm:text-4xl">{p.title}</h1>
        <p className="mt-3 leading-relaxed text-muted-foreground">{p.subtitle}</p>
      </header>

      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <article className="flex flex-col rounded-3xl border bg-card p-6">
          <h2 className="text-lg font-bold">{p.free}</h2>
          <p className="mt-2 text-4xl font-extrabold" dir="ltr">
            {p.currency}{p.freePrice}
          </p>
          <ul className="mt-6 flex flex-1 flex-col gap-3">
            {p.freeFeatures.map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Check className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
                {f}
              </li>
            ))}
          </ul>
          <Button variant="outline" size="lg" className="mt-6 rounded-full" disabled>
            {p.current}
          </Button>
        </article>

        <article className="relative flex flex-col rounded-3xl border-2 border-primary bg-card p-6 shadow-lg">
          <Badge className="absolute -top-3 start-6 bg-accent text-accent-foreground">{p.popular}</Badge>
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <Crown className="size-5 text-accent" aria-hidden="true" />
            {p.pro}
          </h2>
          <p className="mt-2 flex items-baseline gap-1">
            <span className="text-4xl font-extrabold" dir="ltr">{p.currency}{p.proPrice}</span>
            <span className="text-muted-foreground">{p.perMonth}</span>
          </p>
          <ul className="mt-6 flex flex-1 flex-col gap-3">
            {[...p.freeFeatures.slice(0, 1), ...p.proFeatures].map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Check className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
                {f}
              </li>
            ))}
          </ul>
          <Button size="lg" className="mt-6 rounded-full" onClick={() => setNotice(true)}>
            <Crown aria-hidden="true" />
            {p.upgrade}
          </Button>
          {notice && (
            <p role="status" className="mt-3 flex items-start gap-2 rounded-xl bg-secondary p-3 text-sm text-secondary-foreground">
              <Info className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
              {p.soon}
            </p>
          )}
        </article>
      </div>
    </div>
  )
}
